/* ==========================================================================
   Electro Jotabê — dados de catálogo
   Substitua/expanda estes dados pelos produtos reais da loja.
   ========================================================================== */

const CATEGORIES = [
  {
    id: "eletrodomesticos",
    name: "Eletrodomésticos",
    subcategories: [
      { id: "frigorificos", name: "Frigoríficos" },
      { id: "maq-lavar-roupa", name: "Máquinas de Lavar Roupa" },
      { id: "maq-lavar-loica", name: "Máquinas de Lavar Loiça" },
      { id: "fogoes-fornos", name: "Fogões e Fornos" },
      { id: "micro-ondas", name: "Micro-ondas" }
    ]
  },
  {
    id: "tv-som",
    name: "TV e Som",
    subcategories: [
      { id: "televisores", name: "Televisores" },
      { id: "soundbars", name: "Soundbars" },
      { id: "colunas", name: "Colunas" },
      { id: "auscultadores", name: "Auscultadores" }
    ]
  },
  {
    id: "cuidado-pessoal",
    name: "Cuidado Pessoal",
    subcategories: [
      { id: "maq-barbear", name: "Máquinas de Barbear" },
      { id: "secadores", name: "Secadores de Cabelo" },
      { id: "escovas-dentes", name: "Escovas de Dentes Elétricas" }
    ]
  }
];

/* icon: chave que corresponde a um ícone SVG definido em main.js (ICONS)
   efficiency: "A" a "G" (escala energética UE) ou null se não aplicável
   sales: nº de vendas acumuladas, usado para ordenar por "mais vendidos"
   promoPrice: se definido, o produto aparece em Promoções               */

const PRODUCTS = [
  { id: "p01", brand: "Balay", model: "3KFE563WI", category: "eletrodomesticos", subcategory: "frigorificos", icon: "fridge", price: 649.99, promoPrice: 549.99, efficiency: "D", sales: 132 },
  { id: "p02", brand: "Bosch", model: "KGN39VICT", category: "eletrodomesticos", subcategory: "frigorificos", icon: "fridge", price: 899.00, promoPrice: null, efficiency: "C", sales: 98 },
  { id: "p03", brand: "Samsung", model: "RB34C670", category: "eletrodomesticos", subcategory: "frigorificos", icon: "fridge", price: 779.50, promoPrice: null, efficiency: "E", sales: 61 },

  { id: "p04", brand: "LG", model: "F4WV5010", category: "eletrodomesticos", subcategory: "maq-lavar-roupa", icon: "washer", price: 429.00, promoPrice: 369.00, efficiency: "B", sales: 210 },
  { id: "p05", brand: "Bosch", model: "WAN28259ES", category: "eletrodomesticos", subcategory: "maq-lavar-roupa", icon: "washer", price: 499.99, promoPrice: null, efficiency: "A", sales: 88 },
  { id: "p06", brand: "Whirlpool", model: "FFB 8258", category: "eletrodomesticos", subcategory: "maq-lavar-roupa", icon: "washer", price: 349.00, promoPrice: null, efficiency: "C", sales: 54 },

  { id: "p07", brand: "Beko", model: "BDIN36520Q", category: "eletrodomesticos", subcategory: "maq-lavar-loica", icon: "dishwasher", price: 389.00, promoPrice: null, efficiency: "D", sales: 47 },
  { id: "p08", brand: "Siemens", model: "SN23EW14CE", category: "eletrodomesticos", subcategory: "maq-lavar-loica", icon: "dishwasher", price: 459.90, promoPrice: 399.90, efficiency: "C", sales: 76 },

  { id: "p09", brand: "Teka", model: "HSB 640", category: "eletrodomesticos", subcategory: "fogoes-fornos", icon: "oven", price: 259.00, promoPrice: null, efficiency: "A", sales: 39 },
  { id: "p10", brand: "AEG", model: "BPK555260M", category: "eletrodomesticos", subcategory: "fogoes-fornos", icon: "oven", price: 549.00, promoPrice: 489.00, efficiency: "A", sales: 65 },

  { id: "p11", brand: "Samsung", model: "MS23K3555", category: "eletrodomesticos", subcategory: "micro-ondas", icon: "microwave", price: 89.99, promoPrice: null, efficiency: null, sales: 154 },
  { id: "p12", brand: "LG", model: "MH6535GIS", category: "eletrodomesticos", subcategory: "micro-ondas", icon: "microwave", price: 119.00, promoPrice: 99.00, efficiency: null, sales: 71 },

  { id: "p13", brand: "LG", model: "OLED55C4", category: "tv-som", subcategory: "televisores", icon: "tv", price: 1399.00, promoPrice: 1199.00, efficiency: "F", sales: 143 },
  { id: "p14", brand: "Samsung", model: "QE55Q6C", category: "tv-som", subcategory: "televisores", icon: "tv", price: 799.00, promoPrice: null, efficiency: "E", sales: 190 },
  { id: "p15", brand: "TCL", model: "43P635", category: "tv-som", subcategory: "televisores", icon: "tv", price: 349.00, promoPrice: null, efficiency: "D", sales: 122 },

  { id: "p16", brand: "Sonos", model: "Beam Gen2", category: "tv-som", subcategory: "soundbars", icon: "soundbar", price: 469.00, promoPrice: null, efficiency: null, sales: 58 },
  { id: "p17", brand: "JBL", model: "Bar 300", category: "tv-som", subcategory: "soundbars", icon: "soundbar", price: 329.00, promoPrice: 279.00, efficiency: null, sales: 84 },

  { id: "p18", brand: "JBL", model: "Flip 6", category: "tv-som", subcategory: "colunas", icon: "speaker", price: 119.99, promoPrice: null, efficiency: null, sales: 233 },
  { id: "p19", brand: "Bose", model: "SoundLink Flex", category: "tv-som", subcategory: "colunas", icon: "speaker", price: 179.00, promoPrice: 149.00, efficiency: null, sales: 97 },

  { id: "p20", brand: "Sony", model: "WH-CH720N", category: "tv-som", subcategory: "auscultadores", icon: "headphones", price: 129.00, promoPrice: null, efficiency: null, sales: 176 },

  { id: "p21", brand: "Philips", model: "S5588/30", category: "cuidado-pessoal", subcategory: "maq-barbear", icon: "shaver", price: 89.90, promoPrice: 74.90, efficiency: null, sales: 112 },
  { id: "p22", brand: "Braun", model: "Series 7 71-N1200s", category: "cuidado-pessoal", subcategory: "maq-barbear", icon: "shaver", price: 149.00, promoPrice: null, efficiency: null, sales: 69 },

  { id: "p23", brand: "Remington", model: "D3190", category: "cuidado-pessoal", subcategory: "secadores", icon: "dryer", price: 24.99, promoPrice: null, efficiency: null, sales: 201 },
  { id: "p24", brand: "Philips", model: "BHD360/00", category: "cuidado-pessoal", subcategory: "secadores", icon: "dryer", price: 44.90, promoPrice: 36.90, efficiency: null, sales: 88 },

  { id: "p25", brand: "Oral-B", model: "Pro 3 3000", category: "cuidado-pessoal", subcategory: "escovas-dentes", icon: "toothbrush", price: 54.99, promoPrice: null, efficiency: null, sales: 145 },
  { id: "p26", brand: "Philips", model: "Sonicare 4300", category: "cuidado-pessoal", subcategory: "escovas-dentes", icon: "toothbrush", price: 49.90, promoPrice: 39.90, efficiency: null, sales: 60 }
];
