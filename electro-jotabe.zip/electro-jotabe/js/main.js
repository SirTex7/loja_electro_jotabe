/* ==========================================================================
   Electro Jotabê — comportamento partilhado por todas as páginas
   ========================================================================== */

/* ---------- ícones de linha (SVG), um por tipo de produto ---------- */
const ICONS = {
  fridge: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="12" y="4" width="24" height="40" rx="2"/><line x1="12" y1="18" x2="36" y2="18"/><line x1="17" y1="8" x2="17" y2="14"/><line x1="17" y1="22" x2="17" y2="30"/></svg>`,
  washer: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="7" y="6" width="34" height="36" rx="2"/><circle cx="24" cy="26" r="10"/><circle cx="24" cy="26" r="4.5"/><line x1="13" y1="12" x2="17" y2="12"/><circle cx="32" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg>`,
  dishwasher: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="7" y="6" width="34" height="36" rx="2"/><rect x="12" y="12" width="24" height="4" rx="1"/><circle cx="15" cy="28" r="1.6" fill="currentColor" stroke="none"/><line x1="21" y1="26" x2="33" y2="26"/><line x1="21" y1="32" x2="33" y2="32"/></svg>`,
  oven: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="6" y="6" width="36" height="36" rx="2"/><rect x="11" y="20" width="26" height="16" rx="1.5"/><circle cx="14" cy="13" r="2"/><circle cx="21" cy="13" r="2"/><circle cx="28" cy="13" r="2"/></svg>`,
  microwave: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="10" width="40" height="26" rx="2"/><rect x="8" y="14" width="24" height="18" rx="1"/><circle cx="38" cy="18" r="2"/><line x1="35" y1="26" x2="41" y2="26"/><line x1="35" y1="30" x2="41" y2="30"/></svg>`,
  tv: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="8" width="40" height="25" rx="2"/><line x1="18" y1="40" x2="30" y2="40"/><line x1="24" y1="33" x2="24" y2="40"/></svg>`,
  soundbar: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="19" width="40" height="10" rx="4"/><circle cx="13" cy="24" r="1.5" fill="currentColor" stroke="none"/><circle cx="20" cy="24" r="1.5" fill="currentColor" stroke="none"/><circle cx="38" cy="24" r="2" /></svg>`,
  speaker: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="14" y="4" width="20" height="40" rx="3"/><circle cx="24" cy="15" r="4"/><circle cx="24" cy="30" r="6"/></svg>`,
  headphones: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M8 28v-6a16 16 0 0 1 32 0v6"/><rect x="5" y="26" width="9" height="14" rx="3"/><rect x="34" y="26" width="9" height="14" rx="3"/></svg>`,
  shaver: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="16" y="16" width="16" height="26" rx="4"/><rect x="14" y="6" width="20" height="12" rx="5"/><line x1="20" y1="24" x2="28" y2="24"/><line x1="20" y1="30" x2="28" y2="30"/></svg>`,
  dryer: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M10 16h20a8 8 0 0 1 0 16H26"/><rect x="14" y="24" width="10" height="16" rx="3"/><line x1="34" y1="20" x2="43" y2="18"/><line x1="34" y1="24" x2="44" y2="24"/><line x1="34" y1="28" x2="43" y2="30"/></svg>`,
  toothbrush: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="18" y="20" width="8" height="24" rx="3"/><path d="M22 20V8a4 4 0 0 1 8-1"/><line x1="30" y1="6" x2="36" y2="6"/><line x1="31" y1="10" x2="37" y2="10"/><line x1="30" y1="14" x2="36" y2="14"/></svg>`
};

const CATEGORY_ICONS = { "eletrodomesticos": "fridge", "tv-som": "tv", "cuidado-pessoal": "shaver" };

/* ---------- utilitários ---------- */
function formatPrice(value){
  return value.toLocaleString('pt-PT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
}
function findCategory(id){ return CATEGORIES.find(c => c.id === id); }
function findSubcategory(catId, subId){
  const c = findCategory(catId);
  return c ? c.subcategories.find(s => s.id === subId) : null;
}
function qs(name){ return new URLSearchParams(location.search).get(name); }

/* ---------- construção do cartão de produto ---------- */
function productCardHTML(p){
  const hasPromo = p.promoPrice != null;
  const finalPrice = hasPromo ? p.promoPrice : p.price;
  const energy = p.efficiency
    ? `<span class="energy-badge" data-grade="${p.efficiency}">${p.efficiency}</span>`
    : `<span class="energy-badge is-empty" data-grade="A">–</span>`;

  return `
  <article class="product-card" data-id="${p.id}">
    <div class="product-media">
      ${hasPromo ? `<span class="promo-tag">Promoção</span>` : ''}
      ${ICONS[p.icon] || ''}
    </div>
    <div class="product-body">
      <span class="product-brand">${p.brand}</span>
      <h3 class="product-model">${p.model}</h3>
      <div class="product-meta">
        ${energy}
        <div class="price-block">
          ${hasPromo ? `<span class="price-old">${formatPrice(p.price)}</span>` : ''}
          <span class="price ${hasPromo ? 'is-promo' : ''}">${formatPrice(finalPrice)}</span>
        </div>
      </div>
    </div>
  </article>`;
}

function renderGrid(el, products){
  el.innerHTML = products.map(productCardHTML).join('');
}

/* ---------- navegação: menu deslizante em mobile ---------- */
function initNav(){
  const toggle = document.getElementById('menuToggle');
  const nav = document.getElementById('mainNav');
  const scrim = document.getElementById('navScrim');
  const close = document.getElementById('navClose');
  if (!toggle || !nav) return;

  function open(){ nav.classList.add('is-open'); scrim.classList.add('is-open'); toggle.setAttribute('aria-expanded','true'); }
  function shut(){ nav.classList.remove('is-open'); scrim.classList.remove('is-open'); toggle.setAttribute('aria-expanded','false'); }

  toggle.addEventListener('click', open);
  close && close.addEventListener('click', shut);
  scrim && scrim.addEventListener('click', shut);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') shut(); });

  const produtosDetails = document.getElementById('produtosDetails');
  if (produtosDetails){
    document.addEventListener('click', e => {
      if (window.matchMedia('(min-width: 900px)').matches &&
          produtosDetails.open && !produtosDetails.contains(e.target)){
        produtosDetails.open = false;
      }
    });
  }
}

/* ---------- pesquisa (topo, em todas as páginas) ---------- */
function initHeaderSearch(){
  document.querySelectorAll('.search-form').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const input = form.querySelector('input[type="search"]');
      const val = (input.value || '').trim();
      const url = new URL('produtos.html', location.href);
      if (val) url.searchParams.set('q', val);
      location.href = url.toString();
    });
  });
}

/* ---------- montagem do menu "Produtos" (categorias > subcategorias) ---------- */
function buildCategoryNav(container){
  container.innerHTML = CATEGORIES.map(cat => `
    <div class="cat-block">
      <p class="cat-block-title">${cat.name}</p>
      <ul class="nav-sublist">
        ${cat.subcategories.map(s => `<li><a href="produtos.html?cat=${cat.id}&sub=${s.id}">${s.name}</a></li>`).join('')}
      </ul>
    </div>
  `).join('');
}

/* ---------- construção dos cartões de categoria (homepage) ---------- */
function buildCategoryStrip(container){
  container.innerHTML = CATEGORIES.map(cat => `
    <a class="category-card" href="produtos.html?cat=${cat.id}">
      <span class="icon">${ICONS[CATEGORY_ICONS[cat.id]] || ''}</span>
      <span class="name">${cat.name}</span>
      <span class="count">${cat.subcategories.length} tipos de produto</span>
    </a>
  `).join('');
}

/* ==========================================================================
   Página de catálogo (produtos.html e promocoes.html)
   ========================================================================== */
function initCatalogPage({ promoOnly = false } = {}){
  const grid = document.getElementById('productGrid');
  const countEl = document.getElementById('resultCount');
  const sortSelect = document.getElementById('sortSelect');
  const chipsEl = document.getElementById('subcatChips');
  const emptyEl = document.getElementById('emptyState');
  const searchInput = document.getElementById('pageSearchInput');
  const filterForm = document.getElementById('filterForm');
  const filterToggle = document.getElementById('filterToggleBtn');
  const filterPanel = document.getElementById('filterPanel');
  const filterClose = document.getElementById('filterPanelClose');
  const filterApply = document.getElementById('filterApplyBtn');
  const filterClear = document.getElementById('filterClearBtn');
  const titleEl = document.getElementById('catalogTitle');
  const eyebrowEl = document.getElementById('catalogEyebrow');

  let state = {
    q: qs('q') || '',
    cat: qs('cat') || '',
    sub: qs('sub') || '',
    sort: 'relevance'
  };

  /* preencher filtros de categoria (checkboxes) */
  if (filterForm){
    filterForm.innerHTML = CATEGORIES.map(cat => `
      <fieldset class="filter-group">
        <legend>${cat.name}</legend>
        ${cat.subcategories.map(s => `
          <label class="filter-option">
            <input type="checkbox" name="sub" value="${s.id}" data-cat="${cat.id}" ${state.sub === s.id ? 'checked' : ''}>
            ${s.name}
          </label>
        `).join('')}
      </fieldset>
    `).join('');
  }

  function currentSource(){
    return promoOnly ? PRODUCTS.filter(p => p.promoPrice != null) : PRODUCTS;
  }

  function applyState(){
    let items = currentSource();

    if (state.cat) items = items.filter(p => p.category === state.cat);
    if (state.sub) items = items.filter(p => p.subcategory === state.sub);

    if (state.q){
      const needle = state.q.toLowerCase();
      items = items.filter(p =>
        p.brand.toLowerCase().includes(needle) ||
        p.model.toLowerCase().includes(needle)
      );
    }

    if (state.sort === 'price-asc'){
      items = items.slice().sort((a,b) => (a.promoPrice ?? a.price) - (b.promoPrice ?? b.price));
    } else if (state.sort === 'price-desc'){
      items = items.slice().sort((a,b) => (b.promoPrice ?? b.price) - (a.promoPrice ?? a.price));
    } else if (state.sort === 'bestsellers'){
      items = items.slice().sort((a,b) => b.sales - a.sales);
    }

    renderGrid(grid, items);
    if (countEl) countEl.textContent = items.length === 1 ? '1 produto' : `${items.length} produtos`;
    if (emptyEl) emptyEl.hidden = items.length !== 0;
    if (grid) grid.hidden = items.length === 0;

    updateChips();
    updateHeading();
    syncURL();
  }

  function updateChips(){
    if (!chipsEl) return;
    if (!state.cat){ chipsEl.innerHTML = ''; chipsEl.hidden = true; return; }
    const cat = findCategory(state.cat);
    if (!cat){ chipsEl.hidden = true; return; }
    chipsEl.hidden = false;
    chipsEl.innerHTML = `
      <button class="subcat-chip ${!state.sub ? 'is-active' : ''}" data-sub="">Todos</button>
      ${cat.subcategories.map(s => `
        <button class="subcat-chip ${state.sub === s.id ? 'is-active' : ''}" data-sub="${s.id}">${s.name}</button>
      `).join('')}
    `;
    chipsEl.querySelectorAll('.subcat-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        state.sub = btn.dataset.sub;
        applyState();
      });
    });
  }

  function updateHeading(){
    if (!titleEl) return;
    if (promoOnly){ return; }
    if (state.sub){
      const s = findSubcategory(state.cat, state.sub);
      titleEl.textContent = s ? s.name : 'Produtos';
      eyebrowEl.textContent = findCategory(state.cat)?.name || 'Catálogo';
    } else if (state.cat){
      const c = findCategory(state.cat);
      titleEl.textContent = c ? c.name : 'Produtos';
      eyebrowEl.textContent = 'Catálogo';
    } else {
      titleEl.textContent = 'Todos os produtos';
      eyebrowEl.textContent = 'Catálogo';
    }
  }

  function syncURL(){
    const url = new URL(location.href);
    state.q ? url.searchParams.set('q', state.q) : url.searchParams.delete('q');
    state.cat ? url.searchParams.set('cat', state.cat) : url.searchParams.delete('cat');
    state.sub ? url.searchParams.set('sub', state.sub) : url.searchParams.delete('sub');
    history.replaceState(null, '', url);
  }

  if (searchInput){
    searchInput.value = state.q;
    searchInput.addEventListener('input', () => {
      state.q = searchInput.value.trim();
      applyState();
    });
  }

  if (sortSelect){
    sortSelect.addEventListener('change', () => {
      state.sort = sortSelect.value;
      applyState();
    });
  }

  /* painel de filtros (mobile: folha inferior) */
  function openPanel(){ filterPanel.classList.add('is-open'); }
  function shutPanel(){ filterPanel.classList.remove('is-open'); }
  if (filterToggle){ filterToggle.addEventListener('click', openPanel); }
  if (filterClose){ filterClose.addEventListener('click', shutPanel); }

  if (filterForm){
    filterForm.addEventListener('change', e => {
      const checked = filterForm.querySelectorAll('input[name="sub"]:checked');
      if (checked.length === 1){
        state.sub = checked[0].value;
        state.cat = checked[0].dataset.cat;
      } else if (checked.length === 0){
        state.sub = '';
      }
      // em ecrãs largos aplica de imediato; em mobile só ao premir "Aplicar"
      if (window.matchMedia('(min-width: 900px)').matches) applyState();
    });
  }
  if (filterApply){ filterApply.addEventListener('click', () => { applyState(); shutPanel(); }); }
  if (filterClear){
    filterClear.addEventListener('click', () => {
      state.cat = ''; state.sub = '';
      filterForm.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
      applyState();
    });
  }

  applyState();
}

document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initHeaderSearch();
  const navContainer = document.getElementById('navGroups');
  if (navContainer) buildCategoryNav(navContainer);
  const stripContainer = document.getElementById('categoryStrip');
  if (stripContainer) buildCategoryStrip(stripContainer);
});
